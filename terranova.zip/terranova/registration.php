<!DOCTYPE html>
<html>
    <head>
        <title>Register</title>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap">
        <link rel="stylesheet" href="style/styles.css">
    </head>
    <body style=background-color:#2b3031>
        <form method="post" action="/php/login.php" class="form">
        <!DOCTYPE html>
<html>
    <head>
        <style>
            .form-class{
                margin: 0px 350px 0px 350px;
                text-align: center
            }
        </style>
        <meta charset="utf-8"/>
        <title>
            FIVEHOUSE | Registration
        </title>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open%20Sans"/>
        <link rel="stylesheet" type="text/css" href="./style/styles.css"/>
        <header style=color:white>
        </header>
    </head>
    <body style=background-color:#2A4A50>
        <form style=class:form>
            <fieldset style=class:fieldset>
                <legend style=class:legend>
                    <h1 class=text> Register </h1>
                </legend>
                <input type="text" id="first_name" placeholder="first name" name="name" maxlength="50" required>
        <pre></pre>
                <input type="text" id="last_name" placeholder="last name" name="surname" maxlength="50" required>
        <pre></pre>
                <input type="text" id="username" placeholder="Username" name="username" maxlength="50" required>
        <pre></pre>
                <input type="email" id="email" placeholder="email" name="mail" maxlength="50" required>
        <pre></pre>
                <input type="password" id="password" placeholder="Password" name="password" required>
        <pre>
        </pre>
                <p>already a partner?</br><a href=login.php>click me!</a></p>
            </fieldset>
        </form>
    </body>
</html>