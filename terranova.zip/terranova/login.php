<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap">
        <link rel="stylesheet" href="style/styles.css">
    </head>
    <body style=background-color:#2b3031>
        <form method="post" action="/php/login.php" class="form">
        <!DOCTYPE html>
<html>
    <head>
        <style>
            .form-class{
                margin: 0px 400px 0px 400px;
                text-align: center
            }
        </style>
        <meta charset="utf-8"/>
        <title>
            FIVEHOUSE | Login
        </title>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open%20Sans"/>
        <link rel="stylesheet" type="text/css" href="./style/styles.css"/>
        <header style=color:white>
        </header>
    </head>
    <body style=class:body>
        <form style=color:#FFFFFF style=class:form>
            <fieldset style=class:form>
                <legend style=class:h1>
                    <h1 class=text> Login </h1>
                </legend>
                <input type="text" id="username" placeholder="Username" name="username" maxlength="50" required style=class:placeholder>
        <pre></pre>
                <input type="password" id="password" placeholder="Password" name="password" required style=class:placeholder>
        <pre>
        </pre>
                <p>don't have an account?</br><a href=registration.php>click me!</a></p>
            </fieldset>
        </form>
    </body>
</html>